extends Node
class_name SaveSystem

## Simple JSON save system.
## Saves progress, notebook, book pages, routes, and settings.

const SAVE_PATH := "user://enthana_save.json"

func save_game() -> bool:
	if not has_node("/root/GameManager"):
		return false
	
	var data = {
		"version": 1,
		"time": GameManager.get_current_hour(),
		"objective": GameManager.notebook.current_objective if GameManager.notebook else "",
		"entries": GameManager.notebook.get_all_entries() if GameManager.notebook else [],
		"unlocked_pages": GameManager.notebook.unlocked_book_pages if GameManager.notebook else [],
		"interviewed": GameManager.notebook.interviewed_npcs if GameManager.notebook else [],
		"solved_puzzles": GameManager.notebook.solved_puzzles if GameManager.notebook else [],
		"route_1": GameManager.route_1_completed,
		"route_2": GameManager.route_2_completed,
		"route_3": GameManager.route_3_completed,
		"has_false_accusation": GameManager.notebook.has_evidence_false_accusation if GameManager.notebook else false,
		"has_curse": GameManager.notebook.has_curse_knowledge if GameManager.notebook else false,
		"has_containment": GameManager.notebook.has_containment_method if GameManager.notebook else false
	}
	
	var file = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file == null:
		push_error("Could not open save file for writing")
		return false
	file.store_string(JSON.stringify(data, "\t"))
	file.close()
	print("[Save] Game saved successfully")
	return true

func load_game() -> bool:
	if not FileAccess.file_exists(SAVE_PATH):
		print("[Save] No save file found")
		return false
	
	var file = FileAccess.open(SAVE_PATH, FileAccess.READ)
	if file == null:
		return false
	var json = JSON.new()
	var err = json.parse(file.get_as_text())
	file.close()
	if err != OK:
		push_error("Save file corrupt")
		return false
	
	var data = json.data
	if not has_node("/root/GameManager"):
		return false
	
	# Restore routes (always persist)
	GameManager.route_1_completed = data.get("route_1", false)
	GameManager.route_2_completed = data.get("route_2", false)
	GameManager.route_3_completed = data.get("route_3", false)
	
	# Restore notebook
	if GameManager.notebook:
		GameManager.notebook.current_objective = data.get("objective", GameManager.notebook.current_objective)
		GameManager.notebook.unlocked_book_pages = data.get("unlocked_pages", [])
		GameManager.notebook.interviewed_npcs = data.get("interviewed", [])
		GameManager.notebook.solved_puzzles = data.get("solved_puzzles", [])
		GameManager.notebook.has_evidence_false_accusation = data.get("has_false_accusation", false)
		GameManager.notebook.has_curse_knowledge = data.get("has_curse", false)
		GameManager.notebook.has_containment_method = data.get("has_containment", false)
		# Restore entries carefully
		var saved_entries = data.get("entries", [])
		GameManager.notebook.entries.clear()
		for e in saved_entries:
			GameManager.notebook.entries.append(e)
	
	# Restore book pages
	if GameManager.mysterious_book:
		for page_id in data.get("unlocked_pages", []):
			if GameManager.mysterious_book.pages.has(page_id):
				GameManager.mysterious_book.pages[page_id].unlocked = true
	
	# Restore time
	if GameManager.time_system:
		GameManager.time_system.set_time(data.get("time", 8.0))
	
	print("[Save] Game loaded successfully")
	return true

func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH)

func delete_save() -> void:
	if FileAccess.file_exists(SAVE_PATH):
		DirAccess.remove_absolute(SAVE_PATH)
