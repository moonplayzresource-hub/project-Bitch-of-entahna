extends CharacterBody3D
class_name PlayerController

## First-person controller optimised for low-end devices.
## Supports keyboard/mouse (Windows) and prepares for touch (Android).

@export var walk_speed: float = 4.0
@export var sprint_speed: float = 7.0
@export var jump_velocity: float = 4.5
@export var mouse_sensitivity: float = 0.0025
@export var controller_look_sensitivity: float = 2.5
@export var gravity: float = 12.0

@onready var camera_pivot: Node3D = $CameraPivot
@onready var camera: Camera3D = $CameraPivot/Camera3D
@onready var interaction_ray: RayCast3D = $CameraPivot/Camera3D/InteractionRay
@onready var crosshair: Control = $HUD/Crosshair
@onready var interaction_prompt: Label = $HUD/InteractionPrompt

var is_paused: bool = false
var current_interactable: Node = null
var is_in_dialogue: bool = false

# Touch / virtual joystick support (Android)
var touch_move_vector: Vector2 = Vector2.ZERO
var touch_look_delta: Vector2 = Vector2.ZERO
var is_using_touch: bool = false

func _ready() -> void:
	add_to_group("player")
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	interaction_prompt.visible = false
	# Detect if we are on a mobile platform
	is_using_touch = OS.has_feature("mobile") or OS.has_feature("android")

func _unhandled_input(event: InputEvent) -> void:
	if is_paused or is_in_dialogue:
		return

	# Mouse look (PC)
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		rotate_y(-event.relative.x * mouse_sensitivity)
		camera_pivot.rotate_x(-event.relative.y * mouse_sensitivity)
		camera_pivot.rotation.x = clamp(camera_pivot.rotation.x, deg_to_rad(-85.0), deg_to_rad(85.0))

	# Pause
	if event.is_action_pressed("pause"):
		toggle_pause()

	# Interact
	if event.is_action_pressed("interact"):
		try_interact()

func _physics_process(delta: float) -> void:
	if is_paused or is_in_dialogue:
		return

	# Gravity
	if not is_on_floor():
		velocity.y -= gravity * delta

	# Jump
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = jump_velocity

	# Movement input
	var input_dir := Vector2.ZERO

	if is_using_touch:
		input_dir = touch_move_vector
	else:
		input_dir = Input.get_vector("move_left", "move_right", "move_forward", "move_back")

	var direction := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()

	var speed := sprint_speed if Input.is_action_pressed("sprint") and not is_using_touch else walk_speed
	if is_using_touch and touch_move_vector.length() > 0.7:
		speed = sprint_speed  # treat strong joystick push as sprint

	if direction:
		velocity.x = direction.x * speed
		velocity.z = direction.z * speed
	else:
		velocity.x = move_toward(velocity.x, 0, speed)
		velocity.z = move_toward(velocity.z, 0, speed)

	# Touch look
	if is_using_touch and touch_look_delta != Vector2.ZERO:
		rotate_y(-touch_look_delta.x * mouse_sensitivity * 1.5)
		camera_pivot.rotate_x(-touch_look_delta.y * mouse_sensitivity * 1.5)
		camera_pivot.rotation.x = clamp(camera_pivot.rotation.x, deg_to_rad(-85.0), deg_to_rad(85.0))
		touch_look_delta = Vector2.ZERO

	move_and_slide()

	# Interaction detection
	_update_interaction()

func _update_interaction() -> void:
	if interaction_ray.is_colliding():
		var collider = interaction_ray.get_collider()
		if collider and collider.has_method("interact"):
			current_interactable = collider
			var action_name = collider.get("interaction_text") if "interaction_text" in collider else "Interact"
			if is_using_touch:
				interaction_prompt.text = "[TAP]  " + action_name
			else:
				interaction_prompt.text = "[E / X]  " + action_name
			interaction_prompt.visible = true
			return
	current_interactable = null
	interaction_prompt.visible = false

func try_interact() -> void:
	if current_interactable and current_interactable.has_method("interact"):
		current_interactable.interact(self)

func toggle_pause() -> void:
	is_paused = not is_paused
	get_tree().paused = is_paused
	if is_paused:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	else:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	# The pause menu will listen to the GameManager or we can emit a signal
	if has_node("/root/GameManager"):
		GameManager.set_paused(is_paused)

# Called by the virtual joystick UI
func set_touch_move(vector: Vector2) -> void:
	touch_move_vector = vector

func add_touch_look(delta: Vector2) -> void:
	touch_look_delta += delta
