extends CanvasLayer

## Simple dialogue display. Will be expanded later with choices and notebook integration.

@onready var panel: PanelContainer = $Panel
@onready var name_label: Label = $Panel/VBox/NameLabel
@onready var text_label: Label = $Panel/VBox/TextLabel
@onready var continue_label: Label = $Panel/VBox/ContinueLabel

var is_active: bool = false
var current_lines: PackedStringArray = []
var current_index: int = 0
var speaker_name: String = ""

signal dialogue_finished

func _ready() -> void:
	visible = false
	process_mode = Node.PROCESS_MODE_ALWAYS
	add_to_group("dialogue_ui")

func _unhandled_input(event: InputEvent) -> void:
	if not is_active:
		return
	if event.is_action_pressed("interact") or event.is_action_pressed("ui_accept") or (event is InputEventMouseButton and event.pressed) or (event is InputEventKey and event.pressed and event.keycode == KEY_X):
		_advance()
		get_viewport().set_input_as_handled()

func show_dialogue(speaker: String, lines: PackedStringArray) -> void:
	if lines.is_empty():
		return
	speaker_name = speaker
	current_lines = lines
	current_index = 0
	is_active = true
	visible = true
	_update_display()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	# Stop player movement
	var player = get_tree().get_first_node_in_group("player")
	if player and "is_in_dialogue" in player:
		player.is_in_dialogue = true

func _update_display() -> void:
	name_label.text = speaker_name
	text_label.text = current_lines[current_index]
	continue_label.text = "[E] / Click  Continue" if current_index < current_lines.size() - 1 else "[E] / Click  Close"

func _advance() -> void:
	current_index += 1
	if current_index >= current_lines.size():
		_close()
	else:
		_update_display()

func _close() -> void:
	is_active = false
	visible = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	var player = get_tree().get_first_node_in_group("player")
	if player and "is_in_dialogue" in player:
		player.is_in_dialogue = false
	dialogue_finished.emit()
