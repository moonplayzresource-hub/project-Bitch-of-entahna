extends CanvasLayer

@onready var resume_button: Button = $Panel/VBox/ResumeButton
@onready var settings_button: Button = $Panel/VBox/SettingsButton
@onready var quit_button: Button = $Panel/VBox/QuitButton

func _ready() -> void:
	visible = false
	process_mode = Node.PROCESS_MODE_ALWAYS
	resume_button.pressed.connect(_on_resume)
	settings_button.pressed.connect(_on_settings)
	quit_button.pressed.connect(_on_quit)
	
	if has_node("/root/GameManager"):
		GameManager.paused_changed.connect(_on_paused_changed)

func _on_paused_changed(is_paused: bool) -> void:
	visible = is_paused
	if is_paused:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	else:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _on_resume() -> void:
	GameManager.set_paused(false)

func _on_settings() -> void:
	# Will be expanded in Phase 5
	print("Settings menu - coming in Phase 5")

func _on_quit() -> void:
	get_tree().quit()
