extends CanvasLayer

## Mysterious Book interface. Opened when the player interacts with the book object.

@onready var panel: PanelContainer = $Panel
@onready var title_label: Label = $Panel/VBox/TitleLabel
@onready var page_list: ItemList = $Panel/VBox/PageList
@onready var content_label: Label = $Panel/VBox/ContentLabel
@onready var close_button: Button = $Panel/VBox/CloseButton

var is_open: bool = false

func _ready() -> void:
	visible = false
	process_mode = Node.PROCESS_MODE_ALWAYS
	close_button.pressed.connect(close)
	page_list.item_selected.connect(_on_page_selected)
	add_to_group("book_ui")

func open() -> void:
	is_open = true
	visible = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_refresh()
	var player = get_tree().get_first_node_in_group("player")
	if player and "is_in_dialogue" in player:
		player.is_in_dialogue = true
	if has_node("/root/GameManager") and GameManager.mysterious_book:
		GameManager.mysterious_book.open_book()

func close() -> void:
	is_open = false
	visible = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	var player = get_tree().get_first_node_in_group("player")
	if player and "is_in_dialogue" in player:
		player.is_in_dialogue = false
	if has_node("/root/GameManager") and GameManager.mysterious_book:
		GameManager.mysterious_book.close_book()

func _refresh() -> void:
	page_list.clear()
	if not has_node("/root/GameManager") or not GameManager.mysterious_book:
		return
	var pages = GameManager.mysterious_book.get_unlocked_pages()
	for p in pages:
		page_list.add_item("%d. %s" % [p.id, p.title])
	if pages.size() > 0:
		page_list.select(0)
		_on_page_selected(0)
	else:
		content_label.text = "The book is sealed. Find clues to unlock its pages."

func _on_page_selected(index: int) -> void:
	var pages = GameManager.mysterious_book.get_unlocked_pages()
	if index >= 0 and index < pages.size():
		title_label.text = pages[index].title
		content_label.text = pages[index].text
