extends CanvasLayer

## Notebook interface. Open with N key (PC) or a button later.

@onready var panel: PanelContainer = $Panel
@onready var objective_label: Label = $Panel/VBox/ObjectiveLabel
@onready var entries_list: ItemList = $Panel/VBox/EntriesList
@onready var detail_label: Label = $Panel/VBox/DetailLabel
@onready var close_button: Button = $Panel/VBox/CloseButton

var is_open: bool = false

func _ready() -> void:
	add_to_group("notebook_ui")
	visible = false
	process_mode = Node.PROCESS_MODE_ALWAYS
	close_button.pressed.connect(close)
	entries_list.item_selected.connect(_on_entry_selected)
	if has_node("/root/GameManager") and GameManager.notebook:
		GameManager.notebook.entry_added.connect(_on_entry_added)
		GameManager.notebook.objective_changed.connect(_on_objective_changed)
		_refresh()

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel") and is_open:
		close()
		get_viewport().set_input_as_handled()
	# N key to toggle notebook
	if event is InputEventKey and event.pressed and event.keycode == KEY_N and not is_open:
		open()
		get_viewport().set_input_as_handled()

func open() -> void:
	is_open = true
	visible = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_refresh()
	var player = get_tree().get_first_node_in_group("player")
	if player and "is_in_dialogue" in player:
		player.is_in_dialogue = true

func close() -> void:
	is_open = false
	visible = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	var player = get_tree().get_first_node_in_group("player")
	if player and "is_in_dialogue" in player:
		player.is_in_dialogue = false

func _refresh() -> void:
	if not has_node("/root/GameManager") or not GameManager.notebook:
		return
	objective_label.text = "Objective: " + GameManager.notebook.current_objective
	entries_list.clear()
	for entry in GameManager.notebook.get_all_entries():
		var type_str = ["Rumour", "Evidence", "Document", "Memory", "Objective"][entry.type]
		entries_list.add_item("[%s] %s" % [type_str, entry.title])
	detail_label.text = "Select an entry to read details."

func _on_entry_selected(index: int) -> void:
	var entries = GameManager.notebook.get_all_entries()
	if index >= 0 and index < entries.size():
		var e = entries[index]
		detail_label.text = e.text + "\n\n— " + e.source + "  (" + e.timestamp + ")"

func _on_entry_added(_entry: Dictionary) -> void:
	if is_open:
		_refresh()

func _on_objective_changed(text: String) -> void:
	if is_open:
		objective_label.text = "Objective: " + text
