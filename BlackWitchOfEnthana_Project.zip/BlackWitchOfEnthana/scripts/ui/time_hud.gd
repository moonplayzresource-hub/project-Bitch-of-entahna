extends CanvasLayer

@onready var time_label: Label = $TimeLabel

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS

func _process(_delta: float) -> void:
	if has_node("/root/GameManager") and GameManager.time_system:
		time_label.text = GameManager.get_time_string()
