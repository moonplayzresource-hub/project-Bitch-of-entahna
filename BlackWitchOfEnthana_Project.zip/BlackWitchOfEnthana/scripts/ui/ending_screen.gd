extends CanvasLayer

## Shown after any ending. Displays which routes are completed.

@onready var title_label: Label = $Panel/VBox/Title
@onready var route1_label: Label = $Panel/VBox/Route1
@onready var route2_label: Label = $Panel/VBox/Route2
@onready var route3_label: Label = $Panel/VBox/Route3
@onready var completion_label: Label = $Panel/VBox/Completion
@onready var continue_button: Button = $Panel/VBox/ContinueButton

func _ready() -> void:
	visible = false
	process_mode = Node.PROCESS_MODE_ALWAYS
	continue_button.pressed.connect(_on_continue)
	add_to_group("ending_screen")

func show_results(just_completed_route: int = 0) -> void:
	visible = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	
	if just_completed_route > 0:
		GameManager.complete_route(just_completed_route)
	
	route1_label.text = "Route 1 — Prove the False Accusation:  " + ("YES" if GameManager.route_1_completed else "NO")
	route2_label.text = "Route 2 — Cure the Village:  " + ("YES" if GameManager.route_2_completed else "NO")
	route3_label.text = "Route 3 — Jail the Witch:  " + ("YES" if GameManager.route_3_completed else "NO")
	
	if GameManager.all_routes_completed():
		completion_label.text = "100% COMPLETION UNLOCKED"
		completion_label.modulate = Color(1.0, 0.85, 0.3)
		title_label.text = "THE BLACK WITCH OF ENTHANA — COMPLETE"
	else:
		completion_label.text = "Start a New Game to pursue the remaining routes."
		title_label.text = "ENDING REACHED"

func _on_continue() -> void:
	# Return to main menu or restart
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/main.tscn")  # Later change to main menu
