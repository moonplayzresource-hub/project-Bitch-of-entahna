extends CanvasLayer

## Virtual joystick + buttons for Android.
## Always visible on mobile. Can be forced on desktop for testing.

@onready var joystick_base: Control = $LeftJoystick
@onready var joystick_knob: ColorRect = $LeftJoystick/Knob
@onready var interact_btn: Button = $InteractButton
@onready var pause_btn: Button = $PauseButton
@onready var notebook_btn: Button = $NotebookButton

var joystick_center: Vector2
var joystick_radius: float = 75.0
var touch_index_joystick: int = -1
var touch_index_look: int = -1
var last_look_pos: Vector2 = Vector2.ZERO

var player: PlayerController = null

# Set true temporarily if you want to see & test touch UI on Windows
@export var force_show_on_desktop: bool = false

func _ready() -> void:
	var is_mobile = OS.has_feature("mobile") or OS.has_feature("android") or OS.has_feature("ios")
	visible = is_mobile or force_show_on_desktop

	if not visible:
		return

	joystick_center = joystick_base.size / 2.0
	interact_btn.pressed.connect(_on_interact)
	pause_btn.pressed.connect(_on_pause)
	if notebook_btn:
		notebook_btn.pressed.connect(_on_notebook)

	await get_tree().process_frame
	player = get_tree().get_first_node_in_group("player") as PlayerController

func _input(event: InputEvent) -> void:
	if not visible or not player:
		return

	if event is InputEventScreenTouch:
		_handle_touch(event)
	elif event is InputEventScreenDrag:
		_handle_drag(event)

func _handle_touch(event: InputEventScreenTouch) -> void:
	if event.pressed:
		var local_pos = joystick_base.get_local_mouse_position()
		if Rect2(Vector2.ZERO, joystick_base.size).has_point(local_pos) and touch_index_joystick == -1:
			touch_index_joystick = event.index
			_update_joystick(local_pos)
		else:
			if event.position.x > get_viewport().get_visible_rect().size.x * 0.4 and touch_index_look == -1:
				touch_index_look = event.index
				last_look_pos = event.position
	else:
		if event.index == touch_index_joystick:
			touch_index_joystick = -1
			joystick_knob.position = joystick_center - joystick_knob.size / 2.0
			if player:
				player.set_touch_move(Vector2.ZERO)
		if event.index == touch_index_look:
			touch_index_look = -1

func _handle_drag(event: InputEventScreenDrag) -> void:
	if event.index == touch_index_joystick:
		_update_joystick(joystick_base.get_local_mouse_position())
	elif event.index == touch_index_look:
		var delta = event.position - last_look_pos
		last_look_pos = event.position
		if player:
			player.add_touch_look(delta * 0.9)

func _update_joystick(local_pos: Vector2) -> void:
	var offset = local_pos - joystick_center
	if offset.length() > joystick_radius:
		offset = offset.normalized() * joystick_radius
	joystick_knob.position = joystick_center + offset - joystick_knob.size / 2.0
	var move_vec = offset / joystick_radius
	move_vec.y = -move_vec.y
	if player:
		player.set_touch_move(move_vec)

func _on_interact() -> void:
	if player:
		player.try_interact()

func _on_pause() -> void:
	if player:
		player.toggle_pause()

func _on_notebook() -> void:
	var nb = get_tree().get_first_node_in_group("notebook_ui")
	if nb and nb.has_method("open"):
		nb.open()
