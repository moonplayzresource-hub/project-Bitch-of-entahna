extends Node
class_name TimeSystem

## Day / Night cycle controller.
## Game starts at 8:00 AM.
## At 8:59 PM the village bell rings.
## At exactly 9:00 PM villagers return home and lockdown begins.

signal hour_changed(hour: float)
signal day_started
signal night_started
signal lockdown_started
signal morning_started

@export var real_minutes_per_game_day: float = 24.0  # 24 real minutes = 1 full game day
@export var start_hour: float = 8.0                  # 8:00 AM

var current_hour: float = 8.0
var is_locked_down: bool = false
var is_night: bool = false
var time_paused: bool = false

# Important times
const LOCKDOWN_WARNING_HOUR := 20.983   # 8:59 PM
const LOCKDOWN_HOUR := 21.0             # 9:00 PM
const MORNING_HOUR := 6.0               # 6:00 AM

func _ready() -> void:
	current_hour = start_hour
	process_mode = Node.PROCESS_MODE_PAUSABLE

func _process(delta: float) -> void:
	if time_paused or get_tree().paused:
		return

	var hours_per_second = 24.0 / (real_minutes_per_game_day * 60.0)
	var previous_hour = current_hour
	current_hour += hours_per_second * delta

	if current_hour >= 24.0:
		current_hour -= 24.0

	# Detect important transitions
	_check_transitions(previous_hour, current_hour)

	if int(previous_hour) != int(current_hour):
		hour_changed.emit(current_hour)

func _check_transitions(prev: float, curr: float) -> void:
	# Night begins around 18:00
	if prev < 18.0 and curr >= 18.0:
		is_night = true
		night_started.emit()

	# Lockdown warning (bell)
	if prev < LOCKDOWN_WARNING_HOUR and curr >= LOCKDOWN_WARNING_HOUR:
		# Bell will be played by the world
		pass

	# Exact lockdown
	if prev < LOCKDOWN_HOUR and curr >= LOCKDOWN_HOUR:
		is_locked_down = true
		lockdown_started.emit()

	# Morning
	if prev < MORNING_HOUR and curr >= MORNING_HOUR:
		is_locked_down = false
		is_night = false
		morning_started.emit()
		day_started.emit()

func get_formatted_time() -> String:
	var h = int(current_hour) % 24
	var m = int((current_hour - floor(current_hour)) * 60.0)
	var suffix = "AM" if h < 12 else "PM"
	var display_h = h % 12
	if display_h == 0:
		display_h = 12
	return "%d:%02d %s" % [display_h, m, suffix]

func get_hour() -> float:
	return current_hour

func is_daytime() -> bool:
	return current_hour >= 6.0 and current_hour < 18.0

func set_time(hour: float) -> void:
	current_hour = clamp(hour, 0.0, 23.999)
	hour_changed.emit(current_hour)

func pause_time(value: bool) -> void:
	time_paused = value
