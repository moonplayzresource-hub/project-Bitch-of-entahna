extends StaticBody3D
class_name Interactable

## Base class for anything the player can interact with (NPCs, doors, books, objects).

@export var interaction_text: String = "Interact"
@export var one_shot: bool = false

var has_been_interacted: bool = false

func interact(player: Node) -> void:
	if one_shot and has_been_interacted:
		return
	has_been_interacted = true
	_on_interact(player)

func _on_interact(player: Node) -> void:
	# Override in child scripts
	print("Interacted with: ", name)
