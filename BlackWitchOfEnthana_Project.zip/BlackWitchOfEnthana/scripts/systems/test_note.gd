extends Interactable

@export var note_title: String = "Old Note"
@export var note_text: String = "The women have all vanished. No fever. No bodies. Just empty beds.\n\n— A villager of Enthana"

func _on_interact(player: Node) -> void:
	print("=== ", note_title, " ===")
	print(note_text)
	print("====================")
	# Later this will open a proper UI panel and add to the notebook
