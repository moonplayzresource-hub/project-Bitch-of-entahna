extends Node

## Global Game Manager - Autoload
## Handles pause, time, notebook, mysterious book, route tracking, and save data.

signal paused_changed(is_paused: bool)

var is_paused: bool = false
var time_system: TimeSystem
var notebook: Notebook
var mysterious_book: MysteriousBook

# Route completion (persists across playthroughs)
var route_1_completed: bool = false  # Prove the False Accusation
var route_2_completed: bool = false  # Cure the Village
var route_3_completed: bool = false  # Jail the Witch

# Current playthrough route progress
var can_complete_route_1: bool = false
var can_complete_route_2: bool = false
var can_complete_route_3: bool = false

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	
	time_system = TimeSystem.new()
	time_system.name = "TimeSystem"
	add_child(time_system)
	
	notebook = Notebook.new()
	notebook.name = "Notebook"
	add_child(notebook)
	
	mysterious_book = MysteriousBook.new()
	mysterious_book.name = "MysteriousBook"
	add_child(mysterious_book)

func set_paused(value: bool) -> void:
	is_paused = value
	get_tree().paused = value
	paused_changed.emit(value)

func toggle_pause() -> void:
	set_paused(not is_paused)

func get_time_string() -> String:
	if time_system:
		return time_system.get_formatted_time()
	return "8:00 AM"

func get_current_hour() -> float:
	if time_system:
		return time_system.get_hour()
	return 8.0

func check_route_conditions() -> void:
	if notebook:
		can_complete_route_1 = notebook.has_evidence_false_accusation and notebook.get_evidence_count() >= 4
		can_complete_route_2 = notebook.has_curse_knowledge and notebook.has_page(6)
		can_complete_route_3 = notebook.has_containment_method and notebook.has_page(7)

func complete_route(route_id: int) -> void:
	match route_id:
		1: route_1_completed = true
		2: route_2_completed = true
		3: route_3_completed = true
	print("[Route] Completed route ", route_id)

func all_routes_completed() -> bool:
	return route_1_completed and route_2_completed and route_3_completed
