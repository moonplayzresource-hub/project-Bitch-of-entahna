extends StaticBody3D

## Simple environmental symbol puzzle.
## Player must find three matching symbols in the house and activate them in order.

@export var interaction_text: String = "Examine Symbols"
@export var puzzle_id: String = "house_symbols"
@export var required_order: Array[String] = ["moon", "eye", "tree"]

var current_sequence: Array[String] = []
var is_solved: bool = false

func interact(_player: Node) -> void:
	if is_solved:
		print("The symbols already glow with a faint light.")
		return
	
	# For prototype: cycle through the correct sequence automatically when interacted enough times
	# Real version will have three separate interactable symbols
	_try_symbol("moon")
	if current_sequence.size() == 1:
		_try_symbol("eye")
	if current_sequence.size() == 2:
		_try_symbol("tree")

func _try_symbol(symbol: String) -> void:
	current_sequence.append(symbol)
	print("Symbol activated: ", symbol)
	
	# Check correctness
	for i in range(current_sequence.size()):
		if current_sequence[i] != required_order[i]:
			print("The symbols fade. Wrong order.")
			current_sequence.clear()
			return
	
	if current_sequence.size() == required_order.size():
		_solve()

func _solve() -> void:
	is_solved = true
	print("The symbols align. A hidden page is revealed.")
	if has_node("/root/GameManager"):
		GameManager.notebook.mark_puzzle_solved(puzzle_id)
		GameManager.mysterious_book.unlock_page(2)  # The Family
		GameManager.mysterious_book.unlock_page(3)  # The Night
		GameManager.notebook.add_entry(
			"Symbol Puzzle Solved",
			"The three symbols (moon, eye, tree) aligned. New pages appeared in the book.",
			Notebook.EntryType.EVIDENCE,
			"Abandoned House"
		)
		GameManager.notebook.set_objective("Return to the Pandit with what you have learned.")
		GameManager.notebook.has_evidence_false_accusation = true
