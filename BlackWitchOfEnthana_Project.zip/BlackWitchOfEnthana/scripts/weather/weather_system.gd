extends Node
class_name WeatherSystem

## Simple weather controller for atmosphere.
## Changes fog, ambient light, and will later drive rain/thunder particles.

enum Weather { CLEAR, OVERCAST, FOG, RAIN, STORM }

signal weather_changed(new_weather: Weather)

@export var current_weather: Weather = Weather.CLEAR

var env: Environment = null
var sun: DirectionalLight3D = null

func _ready() -> void:
	add_to_group("weather")
	# Find environment and sun after a frame
	await get_tree().process_frame
	_find_nodes()

func _find_nodes() -> void:
	var we = get_tree().get_first_node_in_group("world_environment")
	if we and we is WorldEnvironment:
		env = we.environment
	sun = get_tree().get_first_node_in_group("sun") as DirectionalLight3D

func set_weather(w: Weather) -> void:
	current_weather = w
	_apply()
	weather_changed.emit(w)

func _apply() -> void:
	if not env:
		_find_nodes()
	if not env:
		return
	
	match current_weather:
		Weather.CLEAR:
			env.fog_density = 0.004
			env.fog_light_color = Color(0.55, 0.5, 0.45)
			if sun:
				sun.light_energy = 1.2
		Weather.OVERCAST:
			env.fog_density = 0.01
			env.fog_light_color = Color(0.4, 0.4, 0.42)
			if sun:
				sun.light_energy = 0.7
		Weather.FOG:
			env.fog_density = 0.025
			env.fog_light_color = Color(0.45, 0.45, 0.5)
			if sun:
				sun.light_energy = 0.5
		Weather.RAIN:
			env.fog_density = 0.018
			env.fog_light_color = Color(0.35, 0.38, 0.42)
			if sun:
				sun.light_energy = 0.4
		Weather.STORM:
			env.fog_density = 0.03
			env.fog_light_color = Color(0.25, 0.28, 0.35)
			if sun:
				sun.light_energy = 0.25

func update_from_time(hour: float) -> void:
	# Simple automatic mood based on time
	if hour >= 21.0 or hour < 5.0:
		set_weather(Weather.FOG)
	elif hour >= 18.0:
		set_weather(Weather.OVERCAST)
	else:
		set_weather(Weather.CLEAR)
