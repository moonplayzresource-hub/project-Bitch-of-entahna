extends Node
class_name Notebook

## Central investigation notebook.
## Automatically records important statements, evidence, and clues.
## Distinguishes confirmed evidence from rumours.

signal entry_added(entry: Dictionary)
signal objective_changed(new_objective: String)

enum EntryType { RUMOUR, EVIDENCE, DOCUMENT, MEMORY, OBJECTIVE }

var entries: Array[Dictionary] = []
var current_objective: String = "Explore the village of Enthana and speak with the villagers."
var unlocked_book_pages: Array[int] = []
var interviewed_npcs: Array[String] = []
var solved_puzzles: Array[String] = []
var important_decisions: Dictionary = {}

# Route progress flags (set by specific discoveries)
var has_evidence_false_accusation: bool = false
var has_curse_knowledge: bool = false
var has_containment_method: bool = false

func _ready() -> void:
	add_to_group("notebook")

func add_entry(title: String, text: String, type: EntryType = EntryType.RUMOUR, source: String = "") -> void:
	var entry = {
		"id": entries.size(),
		"title": title,
		"text": text,
		"type": type,
		"source": source,
		"timestamp": GameManager.get_time_string() if has_node("/root/GameManager") else "Unknown"
	}
	entries.append(entry)
	entry_added.emit(entry)
	print("[Notebook] Added: ", title)

func set_objective(text: String) -> void:
	current_objective = text
	objective_changed.emit(text)
	print("[Objective] ", text)

func mark_npc_interviewed(npc_name: String) -> void:
	if npc_name not in interviewed_npcs:
		interviewed_npcs.append(npc_name)

func unlock_book_page(page_id: int) -> void:
	if page_id not in unlocked_book_pages:
		unlocked_book_pages.append(page_id)
		unlocked_book_pages.sort()
		print("[Book] Unlocked page ", page_id)

func has_page(page_id: int) -> bool:
	return page_id in unlocked_book_pages

func mark_puzzle_solved(puzzle_id: String) -> void:
	if puzzle_id not in solved_puzzles:
		solved_puzzles.append(puzzle_id)

func is_puzzle_solved(puzzle_id: String) -> bool:
	return puzzle_id in solved_puzzles

func get_evidence_count() -> int:
	var count = 0
	for e in entries:
		if e.type == EntryType.EVIDENCE or e.type == EntryType.DOCUMENT:
			count += 1
	return count

func get_all_entries() -> Array[Dictionary]:
	return entries.duplicate()
