extends StaticBody3D

## Physical Mysterious Book found in the abandoned house.

@export var interaction_text: String = "Examine the Book"

func interact(_player: Node) -> void:
	var book_ui = get_tree().get_first_node_in_group("book_ui")
	if book_ui and book_ui.has_method("open"):
		book_ui.open()
	else:
		print("Mysterious Book: The pages are sealed. Find more clues.")
	
	# Unlock first real page on first interaction
	if has_node("/root/GameManager") and GameManager.mysterious_book:
		GameManager.mysterious_book.unlock_page(1)
		GameManager.notebook.add_entry(
			"Found the Mysterious Book",
			"A worn leather book with strange symbols. Most pages are sealed.",
			Notebook.EntryType.EVIDENCE,
			"Abandoned House"
		)
		GameManager.notebook.set_objective("Speak with the Pandit and continue exploring the house for more clues.")
