extends Node
class_name MysteriousBook

## The central investigation book found in the abandoned house.
## Pages unlock through exploration, puzzles, and conversations.

signal page_unlocked(page_id: int)
signal book_opened
signal book_closed

var pages: Dictionary = {
	0: {
		"title": "Cover",
		"text": "A worn leather book. Strange symbols mark the cover.\n\nMost pages are missing or sealed.",
		"unlocked": true
	},
	1: {
		"title": "The Accusation",
		"text": "The villagers claimed she practised black magic.\n\nNo one could say what they had witnessed with their own eyes.\nFear spread faster than any proof.",
		"unlocked": false
	},
	2: {
		"title": "The Family",
		"text": "She lived with her husband and a little daughter.\nThe courtyard once held laughter.\nThe drawings on the walls still remain.",
		"unlocked": false
	},
	3: {
		"title": "The Night She Vanished",
		"text": "One night she was gone.\nNo body. No struggle.\nOnly silence and an empty house.",
		"unlocked": false
	},
	4: {
		"title": "Contradiction",
		"text": "The official story says she was killed by something unknown.\n\nYet the Pandit's records mention something else:\na ritual that was never completed.",
		"unlocked": false
	},
	5: {
		"title": "The Disappearances",
		"text": "After that night, the women of Enthana began to vanish.\nNo fever. No bodies.\nOnly empty beds and unanswered questions.",
		"unlocked": false
	},
	6: {
		"title": "The Curse Mechanics",
		"text": "The curse is not random.\nIt binds to fear and unfinished justice.\nTo end it, the truth must be spoken where the accusation was born.",
		"unlocked": false
	},
	7: {
		"title": "Containment",
		"text": "There is another path.\nThe old symbols can bind what they once released.\nBut binding is not the same as understanding.",
		"unlocked": false
	}
}

var is_open: bool = false

func _ready() -> void:
	add_to_group("mysterious_book")

func unlock_page(page_id: int) -> void:
	if pages.has(page_id) and not pages[page_id].unlocked:
		pages[page_id].unlocked = true
		page_unlocked.emit(page_id)
		# Also record in notebook
		var nb = get_tree().get_first_node_in_group("notebook")
		if nb:
			nb.unlock_book_page(page_id)
			nb.add_entry(
				"Book Page: " + pages[page_id].title,
				pages[page_id].text,
				Notebook.EntryType.DOCUMENT,
				"Mysterious Book"
			)
		print("[Mysterious Book] Unlocked page ", page_id, ": ", pages[page_id].title)

func get_unlocked_pages() -> Array:
	var result = []
	for id in pages.keys():
		if pages[id].unlocked:
			result.append({"id": id, "title": pages[id].title, "text": pages[id].text})
	result.sort_custom(func(a, b): return a.id < b.id)
	return result

func is_page_unlocked(page_id: int) -> bool:
	return pages.has(page_id) and pages[page_id].unlocked

func open_book() -> void:
	is_open = true
	book_opened.emit()

func close_book() -> void:
	is_open = false
	book_closed.emit()
