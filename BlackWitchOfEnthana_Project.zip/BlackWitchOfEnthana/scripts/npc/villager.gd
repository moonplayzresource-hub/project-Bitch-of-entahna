extends CharacterBody3D
class_name Villager

## Villager NPC with basic dialogue.
## Schedules and navigation will be added later in Phase 2.

@export var villager_name: String = "Villager"
@export var dialogue_lines: PackedStringArray = [
	"There are no women left in Enthana. Not a single one."
]
@export var interaction_text: String = "Talk"

@onready var name_label: Label3D = $NameLabel

func _ready() -> void:
	if name_label:
		name_label.text = villager_name
	add_to_group("villagers")
	collision_layer = 8  # NPC layer

func interact(_player: Node) -> void:
	var dialogue_ui = get_tree().get_first_node_in_group("dialogue_ui")
	if dialogue_ui and dialogue_ui.has_method("show_dialogue"):
		dialogue_ui.show_dialogue(villager_name, dialogue_lines)
	else:
		for line in dialogue_lines:
			print("[%s]: %s" % [villager_name, line])
