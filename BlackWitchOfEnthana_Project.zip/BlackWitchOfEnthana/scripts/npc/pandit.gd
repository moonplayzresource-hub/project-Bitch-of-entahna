extends "res://scripts/npc/villager.gd"

## The Pandit - key story NPC. Dialogue unlocks with evidence.

@export var dialogue_stage: int = 0

var stage_dialogues: Dictionary = {
	0: PackedStringArray(
		"You seek the truth about the disappearances.",
		"The official story about the Black Witch is... incomplete.",
		"I keep the old records. Bring me something from her house and I may tell you more."
	),
	1: PackedStringArray(
		"This drawing... it was made by the child.",
		"The family lived peacefully. The accusations came later, driven by fear, not proof.",
		"Look for the symbols in the abandoned house. They are the key."
	),
	2: PackedStringArray(
		"You have found the book. Good.",
		"Some pages can only open when the right memories are restored.",
		"The curse began with an unfinished truth. To end it, that truth must be spoken."
	),
	3: PackedStringArray(
		"You now hold enough to choose a path.",
		"Prove the accusation was false... cure the village... or bind what was released.",
		"Each path has a cost. The village will remember which one you chose."
	)
}

func _ready() -> void:
	villager_name = "The Pandit"
	interaction_text = "Talk to the Pandit"
	dialogue_lines = stage_dialogues[0]
	super._ready()
	if name_label:
		name_label.text = villager_name

func interact(player: Node) -> void:
	# Update dialogue based on progress
	_update_stage()
	dialogue_lines = stage_dialogues.get(dialogue_stage, stage_dialogues[0])
	super.interact(player)
	
	# Record interview
	if has_node("/root/GameManager") and GameManager.notebook:
		GameManager.notebook.mark_npc_interviewed("Pandit")
		if dialogue_stage == 0:
			GameManager.notebook.add_entry(
				"Pandit's Warning",
				"The official story about the Black Witch is incomplete. He keeps old records.",
				Notebook.EntryType.RUMOUR,
				"The Pandit"
			)
			GameManager.notebook.set_objective("Explore the Abandoned House and find something to show the Pandit.")

func _update_stage() -> void:
	if not has_node("/root/GameManager"):
		return
	var nb = GameManager.notebook
	var book = GameManager.mysterious_book
	if book and book.is_page_unlocked(2) and dialogue_stage < 1:
		dialogue_stage = 1
	if book and book.is_page_unlocked(4) and dialogue_stage < 2:
		dialogue_stage = 2
	if nb and nb.get_evidence_count() >= 3 and dialogue_stage < 3:
		dialogue_stage = 3
