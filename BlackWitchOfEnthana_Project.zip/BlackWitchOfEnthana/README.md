# THE BLACK WITCH OF ENTHANA

Low-poly 3D first-person horror mystery for **Windows** and **Android**.

**Engine:** Godot 4.7+ (GDScript)

---

## Current Status (Core Systems Across All 5 Phases)

### Phase 1 — Foundation ✓
- First-person controller (WASD + mouse + sprint + jump)
- Interaction system (E)
- Pause menu
- Basic environment + collision
- Android touch controls prepared
- Export presets

### Phase 2 — Village & Dialogue ✓
- Expanded low-poly village
- 4 named villagers + **The Pandit**
- On-screen dialogue UI
- Day/night time system + HUD
- Landmarks (Pandit house, Abandoned house)

### Phase 3 — Investigation ✓
- **Notebook** (press N) — records evidence, rumours, objectives
- **Mysterious Book** system with unlockable pages
- Book object + Book UI
- Symbol puzzle in the Abandoned House interior
- Progressive Pandit dialogue
- Evidence flags for the three routes

### Phase 4 — Horror & Endings (Foundation) ✓
- Weather system (Clear / Overcast / Fog / Rain / Storm)
- Route tracking (3 hidden routes)
- Ending results screen structure
- 100% completion detection

### Phase 5 — Save & Polish (Foundation) ✓
- JSON save / load system
- Route persistence across playthroughs
- Project ready for optimisation and final exports

---

## How to Play the Current Build

1. Open the project in **Godot 4.7.2+**
2. Press **F5**

### Controls
| Input | Action |
|-------|--------|
| WASD | Move |
| Mouse | Look |
| Shift | Sprint |
| Space | Jump |
| E | Interact / Continue dialogue |
| N | Open / Close Notebook |
| Esc | Pause |

### Recommended Play Path
1. Talk to the four villagers (Ramesh, Suresh, Old Man Hari, Kumar)
2. Talk to **The Pandit** (near his labelled house)
3. Walk past the Abandoned House exterior further north to the **interior area**
4. Interact with the **Mysterious Book**
5. Interact with the **Wall Symbols** puzzle (solves and unlocks book pages)
6. Press **N** to open the Notebook and see recorded evidence
7. Return to the Pandit for updated dialogue

---

## What Still Needs Polish (Next Sessions)

- Proper door / scene transition into the abandoned house
- Visual day-night lighting driven by the TimeSystem
- 9:00 PM lockdown (villagers return home)
- Opening cinematic (skippable)
- Full ending sequences for the three routes
- Rain particles + thunder audio
- Main menu + save/load buttons in pause menu
- Final Windows + Android export testing

---

This is a **real, playable investigation prototype** with the full systems architecture required for a complete three-route horror mystery.
