# HOW TO CREATE THE WINDOWS .EXE AND ANDROID APK

This project is ready for export. Follow these exact steps on your computer.

## Requirements (one-time)

1. Godot 4.7.2 Standard (or newer 4.7.x)
2. For Android only:
   - OpenJDK 17
   - Android Studio + SDK (Platform 35, Build-Tools, Platform-Tools)
   - Export templates installed inside Godot (Editor → Manage Export Templates)

## Windows .exe (very easy)

1. Open the project in Godot
2. Project → Export…
3. Select the existing preset **Windows Desktop** (or Add → Windows Desktop)
4. Click **Export Project**
5. Choose a folder (example: `builds/Windows/`)
6. Name it `TheBlackWitchOfEnthana.exe`
7. Click Save

You will get:
- TheBlackWitchOfEnthana.exe
- TheBlackWitchOfEnthana.pck

Both files must stay in the same folder.

## Android APK

1. Editor → Editor Settings → Export → Android
   - Set Java SDK Path (OpenJDK 17 folder)
   - Set Android SDK Path
2. Project → Export…
3. Select the **Android** preset (or Add → Android)
4. Make sure **Gradle Build** is enabled
5. Package → Unique Name: `com.enthana.blackwitch`
6. Click **Export Project**
7. Save as `TheBlackWitchOfEnthana.apk`

Install the APK on your phone (enable “Install from unknown sources” if needed).

## Controls after export

### Windows
| Key | Action |
|-----|--------|
| WASD | Move |
| Mouse | Look |
| Shift | Sprint |
| Space | Jump |
| **E or X** | Interact / Solve Puzzle / Continue Dialogue |
| N | Notebook |
| Esc | Pause |

### Android
- Left virtual joystick = Move
- Drag on right side of screen = Look
- **INTERACT** button = same as E / X
- **PAUSE** button
- **NOTES** button = Notebook

## Testing Android controls on Windows (optional)

In the TouchControls node, set `force_show_on_desktop = true` temporarily.
Then you can see and click the on-screen buttons even on PC.

## Important

- Never claim the .exe or .apk exists until you have actually exported and tested it on your machine.
- If export fails, copy the exact error from the Godot Output panel and send it.
